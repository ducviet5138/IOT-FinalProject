# Wokwi in VSCode
`Lưu ý:` Chỉ hoạt động ổn định trên Linux và MacOS.
## 1. Cài đặt Wokwi trong VSCode
```
https://marketplace.visualstudio.com/items?itemName=Wokwi.wokwi-vscode
```
## 2. Cài đặt PlatformIO trong VSCode để tiến hành build code
```
https://marketplace.visualstudio.com/items?itemName=platformio.platformio-ide
```

## 3. Build code
- B1: Đặt code cần build trong thư mục `src`
- B2: Bấm `Build` trên thanh công cụ hoặc bấm tổ hợp phím `Ctrl+Alt+B`
- B3: Nhấn F1 và chọn `Wokwi: Start Simulator` để tiến hành giả lập