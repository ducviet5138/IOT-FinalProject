# LiquidCrystal_I2C

LiquidCrystal Arduino library for the DFRobot I2C LCD displays

**This library is no longer actively maintained, I only put it here so everyone can access it via the Arduino library manger. If you would like to take the role of the maintainer/owner of the library, please send me a message!**
